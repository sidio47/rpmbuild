if [ "$USER" != "root" -a -n "$PS1" -a -n "$LOGIN_SHELL" -a "$ENVIRONMENT" != "BATCH" ]; then
  [ ! -e $HOME/.noatlogin -a  -x /usr/local/etc/taccinfo ] && \
      /usr/local/etc/taccinfo

  myhost=$(uname -n)
  myhost=${myhost%.tacc.utexas.edu}
  SYSHOST=${myhost#*.}

  fsA=("work")
  if [ "$SYSHOST" = stampede ]; then
      fsA+=("scratch")
  fi

  badFS=""
  for i in "${fsA[@]}"; do
    if ! /usr/local/bin/fsMounted /$i ; then
      badFS="$badFS /$i"
    fi
  done
      
  if [ -n "$badFS" ]; then
    RED=$'\033[1;31m'
    NONE=$'\033[0m'
    echo ""
    echo "${RED}=======================================================================${NONE}"
    echo ""
    echo "The following filesystem(s) are currently unavailable: $badFS"
    echo "You will receive email when they are available again"
    echo ""
    echo "${RED}=======================================================================${NONE}"
    echo ""
    unset RED NONE
  fi
  unset myhost SYSHOST fsA
fi

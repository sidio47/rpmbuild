#!/bin/bash
# -*- shell-script -*-
#############################################
# Get the user's default setting if it exists 
#
#  OR
#
# Load TACC
#############################################

if [ "$USER" != "root" ]; then
  if [ -z "$__Init_Default_Modules" -o -z "$LD_LIBRARY_PATH" ]; then
    if [ "x$SHELL_STARTUP_DEBUG" != x ]; then
      DBG_ECHO "${DBG_INDENT}  Loading Default Modules"
    fi
    umask 077 # set default file/dir protection
    export LMOD_SYSTEM_DEFAULT_MODULES="TACC"

    module --initial_load restore
    export __Init_Default_Modules=1;
    if [ -f $HOME/.modules ]; then
      DBG_INDENT_FUNC up 
      DBG_INDENT_FUNC clear  # This clears the echo function/alias if it exists
      i="~/.modules"
      DBG_ECHO "$DBG_INDENT$i{"
      . $HOME/.modules
      DBG_ECHO "$DBG_INDENT}"
      unset i
      DBG_INDENT_FUNC init   # This turns in back on.
      DBG_INDENT_FUNC down
    fi
  else
    module refresh   # refresh any shell aliases in sub-shells
  fi
fi

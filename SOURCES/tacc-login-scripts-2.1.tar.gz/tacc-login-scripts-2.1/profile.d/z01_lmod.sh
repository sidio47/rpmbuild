#!/bin/sh

if [ -z "$BASH_ENV" ]; then
  export BASH_ENV=/etc/tacc/tacc_functions
fi

if [ $USER != "root" ]; then
  if [ "$TACC_SYSTEM" = "stampedeknl" ]; then
      export LMOD_SYSTEM_NAME=$TACC_SYSTEM
  fi
  
  trap "" 1 2 3

  PS_CMD=/usr/bin/ps
  if [ ! -x $PS_CMD ]; then
     if [ -x /bin/ps ]; then
        PS_CMD=/bin/ps
     fi
  fi
  EXPR_CMD=/usr/bin/expr
  if [ ! -x $EXPR_CMD ]; then
     if [ -x /bin/expr ]; then
        EXPR_CMD=/bin/expr
     fi
  fi
  BASENAME_CMD=/usr/bin/basename
  if [ ! -x $BASENAME_CMD ]; then
      if [ -x /bin/basename ]; then
         BASENAME_CMD=/bin/basename
      fi
  fi

  my_shell=$($PS_CMD -p $$ -ocomm=)
  my_shell=$($EXPR_CMD    "$my_shell" : '-*\(.*\)')
  my_shell=$($BASENAME_CMD $my_shell)
  if [ -f /opt/apps/lmod/lmod/init/$my_shell ]; then
     .    /opt/apps/lmod/lmod/init/$my_shell >/dev/null # Module Support
  else
     .    /opt/apps/lmod/lmod/init/sh        >/dev/null # Module Support
  fi
  unset my_shell PS_CMD EXPR_CMD BASENAME_CMD


  systemMPATH="/opt/apps/xsede/modulefiles /opt/apps/modulefiles /opt/modulefiles"
  if [ "$TACC_SYSTEM" = hikari ]; then
     systemMPATH="/opt/apps/modulefiles /opt/modulefiles"
  fi 
   
  MODULEPATH=`/opt/apps/lmod/lmod/libexec/addto --append MODULEPATH $systemMPATH`
  export MODULEPATH
  
  unset systemMPATH
  trap 1 2 3
fi

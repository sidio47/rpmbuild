#!/bin/bash
# -*- shell-script -*-

if [ "$TACC_SYSTEM" = stampede ]; then

  # IB/MPI env vars to be default values.
  export ARMCI_OPENIB_DEVICE=mlx4_0
  export I_MPI_DAPL_PROVIDER="ofa-v2-mlx4_0-1u"
  export I_MPI_OFA_ADAPTER_NAME=mlx4_0
  export I_MPI_OFA_ADAPTER_NAME=mlx4_0
  export MIC_I_MPI_DAPL_PROVIDER="ofa-v2-mlx4_0-1u"
  export MIC_I_MPI_OFA_ADAPTER_NAME=mlx4_0
  export MV2_IBA_HCA=mlx4_0
fi

#!/bin/bash
# -*- shell-script -*-


TERMDEFAULT=vt100
STTY_ARGS=""				# no extra args for stty(1)
SHNAME=`echo $0 | sed 's/-//'`          # MODULES shell name
SHNAME=`basename $SHNAME`
[ "$SHNAME" = "su" ] && SHNAME="sh"

myhost=$(hostname -f)
myhost=${myhost%.tacc.utexas.edu}
first=${myhost%%.*}
SYSHOST=${myhost#*.}

if [[ $first =~ login-knl[0-9] ]]            || \
   [[ $first =~ c56[1-9]-[0-9][0-9][0-9] ]]; then
    export TACC_SYSTEM=stampedeknl
    export TACC_DOMAIN=stampede
else
    export TACC_SYSTEM=$SYSHOST
    export TACC_DOMAIN=$SYSHOST
fi


if [ "$PS1" ]; then 

  PS1="$first.$SYSHOST(\#)\\$ "
  
  stty $STTY_ARGS erase '^?'		  # set basic terminal characteristics
  stty intr '^C' kill '^U'        
  export TERM
  

  if [ -n "$ZSH_VERSION" ]; then
    PS1="$(print '%2m(%!)')%% "
  else
    bash=${BASH_VERSION%.*}; bmajor=${bash%.*}; 
    if [ "$bmajor" '>' 3 ]; then
      shopt -s direxpand                  # For bash user set directory expansion
    fi
    export PS1                            # Do not export PS1 under zsh
    unset bash bmajor
  fi



fi
unset myhost first SYSHOST
unset STTY_ARGS

export PATH MANPATH MAIL SYSTEM 

ulimit -s unlimited

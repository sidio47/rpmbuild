#!/bin/bash
# -*- shell-script -*-
#############################################
# Get the user's default setting if it exists 
#
#  OR
#
# Load TACC
#############################################

# Compute notes set the ENVIRONMENT var to BATCH for non-interactive shells.
if [ -z "$PS1" ]; then
  export ENVIRONMENT=BATCH
  umask 077 # set default file/dir protection

  # If we are in BATCH mode then turn off the module command.
  if [ -z "$TACC_DEBUG" -a -z "$ZSH_VERSION" ]; then
    export LMOD_CMD=':'
    export LMOD_SETTARG_CMD=':'
  fi
fi

########################################################################
# You may ask why is this test below safe on a compute node.  Obviously,
# we don't want root to load modules so that part is fine.  The trouble
# is with the 2nd part.  It turns out that both SLURM and SGE are doing
# interactive non-prompt shells when starting a job.  Also mpi is also
# starting task also with interactive non-prompt shells.  So in both
# cases LOGIN_SHELL will be undefined.

# But you say what happens with an idev or srun session?  Well it will
# be login shell with a prompt so those shells will pass through the
# first if test.  (Only to be foiled by the second but that is O.K. as 
# the environment is pushed so __Init_Default_Modules will be defined.)

if [ "$USER" != "root" -a -n "$LOGIN_SHELL" ]; then
  if [ -z "$__Init_Default_Modules" -o -z "$LD_LIBRARY_PATH" ]; then

    umask 077 # set default file/dir protection

    if [ "x$SHELL_STARTUP_DEBUG" != x ]; then
      DBG_ECHO "${DBG_INDENT}  Loading Default Modules"
    fi

    export LMOD_SYSTEM_DEFAULT_MODULES="TACC"
    module --initial_load restore
    export __Init_Default_Modules=1
    if [ -f $HOME/.modules ]; then
      DBG_INDENT_FUNC up 
      DBG_INDENT_FUNC clear  # This clears the echo function/alias if it exists
      i="~/.modules"
      if [ "x$SHELL_STARTUP_DEBUG" != x ]; then
        DBG_ECHO "$DBG_INDENT$i{"
      fi
      . $HOME/.modules
      if [ "x$SHELL_STARTUP_DEBUG" != x ]; then
        DBG_ECHO "$DBG_INDENT}"
      fi
      unset i
      DBG_INDENT_FUNC init   # This turns in back on.
      DBG_INDENT_FUNC down
    fi
  else
    module refresh  # re-define all shell aliases for login shells.
  fi
fi

#!/bin/bash
# -*- shell-script -*-

if [ $USER != "root" -a  -n "$PS1" -a "$SHLVL" = 1 ]; then
  idev_hostname=`hostname -f`
  export IDEV_SETUP_BYPASS="1.0"
  export idev_ip=${idev_hostname%%.*}

  if [[ $idev_ip =~ c[0-9][0-9][0-9]-[0-9][0-9][0-9] ]] || \
     [[ $idev_ip =~ vis[0-9]                         ]] || \
     [[ $idev_ip =~ visbig                           ]]; then
  
    for i in /tmp/idev_${USER}_bash_env.[0-9]* /tmp/idev_bash_env.[0-9]*; do
      if [ -r $i ]; then
          . $i
          cd "$IDEV_PWD";
          break
      fi
    done
  fi
fi

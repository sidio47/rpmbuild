if [ $USER != "root" -a  -n "$PS1" -a -n "$LOGIN_SHELL" -a ! -f ~/.no.tips -a -x /opt/apps/tacc_tips/tacc_tips/bin/showTip ]; then
  /opt/apps/tacc_tips/tacc_tips/bin/showTip -w
fi
  

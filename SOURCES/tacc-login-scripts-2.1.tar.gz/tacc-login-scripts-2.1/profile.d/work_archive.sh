#
# Set up work and archive 
#
if [ "$USER" != "root" ]; then

  # Create $WORK, $STOCKYARD, and/or $SCRATCH as necessary.
  myhost=$(uname -n)
  myhost=${myhost%.tacc.utexas.edu}
  SYSHOST=${myhost#*.}

  aliasA=("work" "stockyard")
  if [ "$SYSHOST" = stampede2 ]; then
      aliasA+=("scratch" "oldwork")
      if /usr/local/bin/fsMounted /oldhome1 ; then
          aliasA+=("oldhome1")
      fi
      if /usr/local/bin/fsMounted /oldscratch ; then
          aliasA+=("oldscratch")
      fi
  fi

  if [ "$SYSHOST" = stampede ]; then
      aliasA+=("scratch")
  fi
  if [ "$SYSHOST" = wrangler ]; then
      aliasA+=("data")
  fi

  if [ -x /usr/local/bin/workdir -a -z "$WORK" ]; then
    for i in "${aliasA[@]}"; do
      NAME=$(echo $i | tr '[:lower:]' '[:upper:]')
      NAME=${NAME%%1}                       # Change OLDHOME1 into OLDHOME
      VAL=$(/usr/local/bin/workdir $i)
      eval $NAME=$VAL
      export $NAME
    done
  fi

  if [ -z "$CSR" -a -x /usr/local/bin/workdir ]; then
    /usr/local/bin/fsMounted /csr
    if [ "$?" = 0 ]; then
      CSR=`/usr/local/bin/workdir csr`
      export CSR
    fi
  fi

  if [ -z "$ARCHIVE" -a -x /usr/local/etc/archive ]; then
    ARCHIVE=`/usr/local/etc/archive`
    export  ARCHIVE
  fi

  if [ -z "$ARCHIVER" -a -x /usr/local/etc/archive ]; then
    export ARCHIVER=`/usr/local/etc/archive x`
  fi

                                function cdh  { cd       $HOME/${1:-""}; }
  [ "0$WORK"       != "0" ]  && function cdw  { cd       $WORK/${1:-""}; }
  [ "0$ARCHIVE"    != "0" ]  && function cda  { cd    $ARCHIVE/${1:-""}; }
  [ "0$SCRATCH"    != "0" ]  && function cds  { cd    $SCRATCH/${1:-""}; }
  [ "0$DATA"       != "0" ]  && function cdd  { cd       $DATA/${1:-""}; }
  [ "0$OLDHOME"    != "0" ]  && function cdoh { cd    $OLDHOME/${1:-""}; }
  [ "0$OLDWORK"    != "0" ]  && function cdow { cd    $OLDWORK/${1:-""}; }
  [ "0$OLDSCRATCH" != "0" ]  && function cdos { cd $OLDSCRATCH/${1:-""}; }

  unset myhost SYSHOST aliasA
fi
